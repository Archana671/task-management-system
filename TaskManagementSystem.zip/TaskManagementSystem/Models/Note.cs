﻿using System.Collections.Generic;
using System;
using System.ComponentModel.DataAnnotations;
namespace TaskManagementSystem.Models
{
    public class Note
    {
        public int Id { get; set; }

        [Required]
        public string Content { get; set; }

        [Required]
        public int ProjectTaskId { get; set; } // Foreign key

        public ProjectTask ProjectTask { get; set; } // Navigation property
    }
}
