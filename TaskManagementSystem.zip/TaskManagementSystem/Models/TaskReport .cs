﻿
using System;
using System.ComponentModel.DataAnnotations;

namespace TaskManagementSystem.Models

{
  
    namespace TaskManagementSystem.Models
    {
        public class TaskReport
        {
            public int Id { get; set; }

            [Required]
            public int UserId { get; set; } // Foreign key for the user

            public User User { get; set; } // Navigation property

            [Required]
            public int CompletedTasks { get; set; } // Number of completed tasks

            [Required]
            public int PendingTasks { get; set; } // Number of pending tasks

            [Required]
            public DateTime ReportDate { get; set; } // Date of the report
        }
    }

}
