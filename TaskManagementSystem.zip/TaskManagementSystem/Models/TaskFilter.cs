﻿using System;
using System.ComponentModel.DataAnnotations;

namespace TaskManagementSystem.Models
{
    public class TaskFilter
    {
        [Required]
        public DateTime StartDate { get; set; } // Start date for filtering tasks

        [Required]
        public DateTime EndDate { get; set; } // End date for filtering tasks

        public bool? IsCompleted { get; set; } // Status filter: true for completed, false for pending, null for all

        public int? AssignedUserId { get; set; } // Filter by assigned user, nullable if no specific user filter is applied
    }
}
