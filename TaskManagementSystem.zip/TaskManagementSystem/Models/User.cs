﻿using System.Collections.Generic;
namespace TaskManagementSystem.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Role { get; set; } // Employee, Manager, Admin
        public ICollection<ProjectTask> ProjectTasks { get; set; }
    }
}
