﻿// Models/Task.cs
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
namespace TaskManagementSystem.Models
{
    public class ProjectTask
    {
        public int Id { get; set; }

        [Required]
        public string Title { get; set; }

        [Required]
        public string Description { get; set; }

        [Required]
        public DateTime DueDate { get; set; }

        public bool IsCompleted { get; set; }

        [Required]
        public int AssignedUserId { get; set; }
        public User AssignedUser { get; set; }

        public ICollection<Document> Documents { get; set; } // Navigation property for Documents
        public ICollection<Note> Notes { get; set; } // Navigation property for Notes
    }
}