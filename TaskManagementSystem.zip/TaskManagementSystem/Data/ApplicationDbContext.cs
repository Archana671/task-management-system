﻿using Microsoft.EntityFrameworkCore;
using TaskManagementSystem.Models;
using TaskManagementSystem.Models.TaskManagementSystem.Models;

namespace TaskManagementSystem.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        // Existing DbSets
        public DbSet<ProjectTask> ProjectTasks { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Document> Documents { get; set; }
        public DbSet<Note> Notes { get; set; }

        // New DbSets
        public DbSet<TaskReport> TaskReports { get; set; }
     // This might be more for application use rather than persisted data

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Existing configurations

            modelBuilder.Entity<ProjectTask>()
                .Property(t => t.Title)
                .HasMaxLength(200)
                .IsRequired();

            modelBuilder.Entity<ProjectTask>()
                .Property(t => t.Description)
                .HasMaxLength(1000)
                .IsRequired();

            modelBuilder.Entity<ProjectTask>()
                .HasOne(t => t.AssignedUser)
                .WithMany(u => u.ProjectTasks)
                .HasForeignKey(t => t.AssignedUserId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<ProjectTask>()
                .HasMany(t => t.Documents)
                .WithOne(d => d.ProjectTask)
                .HasForeignKey(d => d.ProjectTaskId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<ProjectTask>()
                .HasMany(t => t.Notes)
                .WithOne(n => n.ProjectTask)
                .HasForeignKey(n => n.ProjectTaskId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<User>()
                .Property(u => u.Name)
                .HasMaxLength(100)
                .IsRequired();

            modelBuilder.Entity<User>()
                .Property(u => u.Role)
                .HasMaxLength(50)
                .IsRequired();

            modelBuilder.Entity<User>()
                .HasIndex(u => u.Name)
                .IsUnique();

            modelBuilder.Entity<Document>()
                .Property(d => d.FilePath)
                .HasMaxLength(500)
                .IsRequired();

            modelBuilder.Entity<Note>()
                .Property(n => n.Content)
                .HasMaxLength(2000)
                .IsRequired();

            // New configurations for TaskReport
            modelBuilder.Entity<TaskReport>()
                .Property(tr => tr.CompletedTasks)
                .IsRequired();

            modelBuilder.Entity<TaskReport>()
                .Property(tr => tr.PendingTasks)
                .IsRequired();

            modelBuilder.Entity<TaskReport>()
                .Property(tr => tr.ReportDate)
                .IsRequired();

            // TaskFilter is usually used in application logic and not persisted, 
            // so you might not need to configure it here unless you decide to persist it.
        }
    }
}
