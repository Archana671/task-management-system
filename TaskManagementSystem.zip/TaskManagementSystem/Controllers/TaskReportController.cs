﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskManagementSystem.Data;
using TaskManagementSystem.Models.TaskManagementSystem.Models;

namespace TaskManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaskReportsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public TaskReportsController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<TaskReport>>> GetTaskReports()
        {
            return await _context.TaskReports.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<TaskReport>> GetTaskReport(int id)
        {
            var taskReport = await _context.TaskReports.FindAsync(id);
            if (taskReport == null) return NotFound();
            return taskReport;
        }

        [HttpPost]
        public async Task<ActionResult<TaskReport>> PostTaskReport(TaskReport taskReport)
        {
            _context.TaskReports.Add(taskReport);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetTaskReport), new { id = taskReport.Id }, taskReport);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutTaskReport(int id, TaskReport taskReport)
        {
            if (id != taskReport.Id) return BadRequest();
            _context.Entry(taskReport).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.TaskReports.Any(e => e.Id == id)) return NotFound();
                else throw;
            }
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTaskReport(int id)
        {
            var taskReport = await _context.TaskReports.FindAsync(id);
            if (taskReport == null) return NotFound();
            _context.TaskReports.Remove(taskReport);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }

}
